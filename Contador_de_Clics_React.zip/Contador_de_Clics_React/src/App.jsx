import { useState } from 'react'

export default function App() {
  const [contador, setContador] = useState(0)
  const [mensaje, setMensaje] = useState('¡Listo para contar!')

  const incrementar = () => {
    setContador((valorActual) => valorActual + 1)
    setMensaje('Contador aumentado en uno.')
  }

  const disminuir = () => {
    if (contador <= 0) {
      setMensaje('Validación: el contador no puede ser menor que cero.')
      return
    }
    setContador((valorActual) => valorActual - 1)
    setMensaje('Contador disminuido en uno.')
  }

  const reiniciar = () => {
    setContador(0)
    setMensaje('El contador se reinició a cero.')
  }

  return (
    <main className="min-h-screen bg-slate-950 px-4 py-10 text-white flex items-center justify-center">
      <section className="w-full max-w-md rounded-3xl border border-slate-700 bg-slate-900 p-7 shadow-2xl sm:p-9">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-500/15 text-3xl">
            🔢
          </div>
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.2em] text-indigo-300">
            Herramienta de conteo
          </p>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Contador de clics</h1>
          <p className="mt-3 text-slate-400">
            Lleva un registro sencillo de tus eventos y observaciones.
          </p>
        </div>

        <div
          className="mb-6 rounded-2xl border border-slate-700 bg-slate-950 px-5 py-8 text-center"
          aria-live="polite"
          aria-label={`Valor del contador: ${contador}`}
        >
          <p className="text-sm font-medium text-slate-400">Valor actual</p>
          <output className="mt-2 block text-7xl font-extrabold tabular-nums text-indigo-300">
            {contador}
          </output>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={incrementar}
            className="rounded-xl bg-emerald-500 px-4 py-4 font-bold text-slate-950 transition hover:bg-emerald-400 focus:outline-none focus:ring-4 focus:ring-emerald-500/30 active:scale-[0.98]"
          >
            + Incrementar
          </button>
          <button
            type="button"
            onClick={disminuir}
            className="rounded-xl bg-rose-500 px-4 py-4 font-bold text-white transition hover:bg-rose-400 focus:outline-none focus:ring-4 focus:ring-rose-500/30 active:scale-[0.98]"
          >
            − Disminuir
          </button>
          <button
            type="button"
            onClick={reiniciar}
            className="col-span-2 rounded-xl border border-slate-600 bg-slate-800 px-4 py-3 font-semibold text-slate-200 transition hover:bg-slate-700 focus:outline-none focus:ring-4 focus:ring-slate-500/30 active:scale-[0.98]"
          >
            ↻ Reiniciar a cero
          </button>
        </div>

        <p className="mt-5 min-h-6 text-center text-sm text-slate-400" role="status">
          {mensaje}
        </p>
        <p className="mt-6 border-t border-slate-800 pt-5 text-center text-xs text-slate-500">
          Aplicación desarrollada con React y Tailwind CSS
        </p>
      </section>
    </main>
  )
}
