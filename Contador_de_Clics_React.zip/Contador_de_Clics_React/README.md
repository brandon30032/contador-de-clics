# Contador de clics

Aplicación desarrollada en React y diseñada con Tailwind CSS para registrar conteos.

## Funcionalidades
- Muestra el contador en tiempo real.
- Incrementa el valor en uno.
- Disminuye el valor en uno.
- Reinicia el contador a cero.
- Validación: no permite que el contador sea menor que cero.
- Diseño adaptable a pantallas pequeñas y grandes.

## Cómo ejecutar el proyecto
1. Instala Node.js en tu computadora: https://nodejs.org/
2. Descomprime el archivo ZIP.
3. Abre la carpeta del proyecto en Visual Studio Code.
4. Abre la terminal dentro de VS Code.
5. Ejecuta `npm install`.
6. Ejecuta `npm run dev`.
7. Abre en el navegador la dirección que muestra la terminal (normalmente `http://localhost:5173`).

## Crear la versión de producción
Ejecuta `npm run build`. Los archivos de salida se generan en la carpeta `dist`.

## Subir a GitHub
Sube el contenido de esta carpeta a un repositorio público y adjunta la URL del repositorio en la plataforma de la clase.
